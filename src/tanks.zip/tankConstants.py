colourList = [(0, 128, 128),    # Turquoise
              (230, 25, 75),    # Pink/Red
              (245, 130, 48),   # Orange
              (79, 143, 35),    # Darkish green
              (143, 35, 35),    # Dark Red
              (143, 106, 35),   # Brown
              (0, 149, 255),    # Royal Blue
              (145, 30, 180),   # Purple
              (220, 180, 150),  # Beige/ Apricot
              (0, 64, 255)      # Dark Blue
              ]
tankMoveSpeed = 5

