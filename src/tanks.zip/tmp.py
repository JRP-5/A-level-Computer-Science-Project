from datetime import datetime
now = datetime.now()
print(now.strftime("%H%M.%S%f"))

